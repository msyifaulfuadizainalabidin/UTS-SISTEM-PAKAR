# UTS Sistem Pakar 2019
Perhitungan min/max menggunakan metode fuzzy
